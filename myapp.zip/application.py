from flask import Flask

application = Flask(__name__)

@application.route('/')
def hello():
    return 'Hello from CKT! This is my first cloud app on AWS.'
