
import socket
def start_server():
    
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
  
    host = '127.0.0.1' 
    port = 12345      

    server_socket.bind((host, port))  
    
    server_socket.listen(5)
    print(f"Server is listening on {host}:{port}...")

    while True:
      
        client_socket, client_address = server_socket.accept()
        print(f"Connection established with {client_address}")
       
        data = client_socket.recv(1024).decode('utf-8')
        print(f"Message from client: {data}")
       
        response = "Hello from the Server! Your message was received."
        client_socket.send(response.encode('utf-8'))
        
        client_socket.close()
        break 

if __name__ == '__main__':
    start_server()
